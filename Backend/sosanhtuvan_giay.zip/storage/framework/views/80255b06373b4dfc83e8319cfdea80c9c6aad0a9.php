<?php $__env->startSection('title','Danh sách câu trả lời'); ?>
<?php $__env->startSection('content'); ?>
	<div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Dashboard</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Dashboard</a></li>
                            <li><a href="#">Quản lí tư vấn</a></li>
                            <li class="active">Danh sách câu trả lời</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <strong class="card-title">Danh sách câu trả lời</strong>
                        </div>
                        <?php if(session()->has('success')): ?>
                            <br/>
                            <div class="alert alert-success text-center">
                                <?php echo e(session('success')); ?>

                            </div>
                            <?php echo e(session()->forget('success')); ?>

                         <?php endif; ?>
                        <div class="card-body">
                  <table id="bootstrap-data-table" class="table table-striped table-bordered">
                    <thead>
                      <tr>
                        <th>Câu trả lời</th>
                        <th>Tùy chỉnh</th> 
                      </tr>
                    </thead>
                    <tbody>
                    <?php if(isset($answers)): ?>
                        <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($answer->answer_content); ?></td>
                            <td style="text-align: center;">
                            <form action="<?php echo e(route('delete.Answer',['id'=>$answer->id])); ?>" method="post">
                                <?php echo e(method_field('DELETE')); ?>

                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <a href="<?php echo e(route('get.Editanswer',['id'=>$answer->id])); ?>"><i class="fas fa-edit" style="color: green; font-size: 20px; margin-right: 15px;" title="Chỉnh sửa"></i></a>
                                <button type="submit" style="background: none; border:none;"><i class="fas fa-trash-alt" style="color: red; font-size: 20px;" title="Xóa"></i></button>
                            </form>
                            </td>    
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                  </table>
                        </div>
                    </div>
                </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->

    <!-- Right Panel -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>